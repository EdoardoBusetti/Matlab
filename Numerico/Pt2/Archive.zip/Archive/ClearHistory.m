function [] = ClearHistory()
com.mathworks.mlservices.MLCommandHistoryServices.removeAll;
clc;